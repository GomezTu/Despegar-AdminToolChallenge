import { combineReducers } from 'redux';
import app from './reducer';

export default combineReducers({
  app
});
